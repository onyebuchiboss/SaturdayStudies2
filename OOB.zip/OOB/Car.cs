﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOB
{
    public class Car : ICar
    {
        public List<CarModel> Models { get; set; } = new List<CarModel>();
        public string? Make { get; set; }

        public string key;

        public Car()
        {
               
        }

        public string GetCarUsingYear(DateOnly date)
        {
            var cars = GenerateCarsData();
            var carModel = cars.Select(x => x.Models);
            var car = carModel?.FirstOrDefault()?.Where(x=>x.RegistrationYear.Equals(date)).FirstOrDefault();

            return car.Model;
        }

        public string GetCarUsingVinNumber(int number)
        {
            var cars = GenerateCarsData();

            return string.Empty;
        }

        public List<Car> GenerateCarsData()
        {
            List<Car> cars = new()
            {
                new Car
                {
                    Models = new List<CarModel>
                    {
                        new CarModel { Model = "Toyota Camry", DoorType = 4, EngineSize = 2.5, Color = "Red", VinNumber = 123456789, RegistrationYear = new DateOnly(2020, 1, 1) },
                        new CarModel { Model = "Toyota Corolla", DoorType = 4, EngineSize = 1.8, Color = "Blue", VinNumber = 223456789, RegistrationYear = new DateOnly(2019, 1, 1) }
                    },
                    Make = "Toyota",
                },
                new Car
                {
                    Models = new List<CarModel>
                    {
                        new CarModel { Model = "Honda Accord", DoorType = 4, EngineSize = 1.5, Color = "Black", VinNumber = 987654321, RegistrationYear = new DateOnly(2018, 1, 1) },
                        new CarModel { Model = "Honda Civic", DoorType = 4, EngineSize = 1.8, Color = "White", VinNumber = 287654321, RegistrationYear = new DateOnly(2019, 1, 1) }
                    },
                    Make = "Honda"
                },
                new Car
                {
                    Models = new List<CarModel>
                    {
                        new CarModel { Model = "Ford Mustang", DoorType = 2, EngineSize = 5.0, Color = "Yellow", VinNumber = 192837465, RegistrationYear = new DateOnly(2021, 1, 1) },
                        new CarModel { Model = "Ford Explorer", DoorType = 4, EngineSize = 3.0, Color = "Green", VinNumber = 392837465, RegistrationYear = new DateOnly(2022, 1, 1) }
                    },
                    Make = "Ford"
                }
            };

            return cars;
        }
    }
}
