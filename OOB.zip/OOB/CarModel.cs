﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOB
{
    public class CarModel
    {
        public string Model { get; set; }
        public int DoorType { get; set; }
        public double EngineSize { get; set; }
        public string Color { get; set; }
        public int VinNumber { get; set; }
        public DateOnly RegistrationYear { get; set; }
    }
}
