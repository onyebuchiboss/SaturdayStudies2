﻿namespace OOB
{
    public interface ICar
    {
        List<Car> GenerateCarsData();
        string GetCarUsingYear(DateOnly date);
        string GetCarUsingVinNumber(int number);
    }
}