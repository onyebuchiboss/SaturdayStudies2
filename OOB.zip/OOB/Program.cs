﻿// See https://aka.ms/new-console-template for more information
using OOB;

Console.WriteLine("Hello Today, and How can I help?");
var response = Console.ReadLine();

if (response.ToLower().Contains("car"))
{
    Car car = new();

    Console.WriteLine("Yes I can help you with cars");
    Console.WriteLine("Can you enter your year of registration");

    var yearOfReg = Console.ReadLine();

    Console.WriteLine("Can you enter your Month of registration");

    var monthOfReg = Console.ReadLine();

    Console.WriteLine("Can you enter your Day of registration");

    var dayOfReg = Console.ReadLine();

    if(dayOfReg != null & monthOfReg != null & yearOfReg != null)
    {
        var carMake = car.GetCarUsingYear(new DateOnly(int.Parse(yearOfReg), int.Parse(monthOfReg), int.Parse(dayOfReg)));

        Console.WriteLine($"your car is {carMake}");
    }
}
